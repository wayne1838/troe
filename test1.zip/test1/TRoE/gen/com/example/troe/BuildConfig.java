/** Automatically generated file. DO NOT MODIFY */
package com.example.troe;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}